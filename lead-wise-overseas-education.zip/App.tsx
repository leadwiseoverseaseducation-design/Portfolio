
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Destinations from './components/Destinations';
import StatsSection from './components/StatsSection';
import AICounselor from './components/AICounselor';
import Testimonials from './components/Testimonials';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [isCounselorOpen, setIsCounselorOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <Hero onCtaClick={() => setIsCounselorOpen(true)} />
        <StatsSection />
        
        <section id="services" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-extrabold text-blue-900 mb-4">Our Premium Services</h2>
              <p className="text-slate-600 max-w-2xl mx-auto text-lg">
                We provide end-to-end solutions to ensure your transition to international education is seamless and successful.
              </p>
            </div>
            <Services />
          </div>
        </section>

        <section id="destinations" className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-extrabold text-blue-900 mb-4">Popular Study Destinations</h2>
              <p className="text-slate-600 max-w-2xl mx-auto text-lg">
                Choose from the world's most prestigious education hubs and start your global journey.
              </p>
            </div>
            <Destinations />
          </div>
        </section>

        <section id="testimonials" className="py-20 bg-white">
          <Testimonials />
        </section>

        <section id="contact" className="py-20 bg-blue-900 text-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-6">Ready to take the next step?</h2>
                <p className="text-blue-100 mb-8 text-lg">
                  Speak with our expert consultants today. We've helped thousands of students achieve their dreams of studying abroad.
                </p>
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-800 rounded-full flex items-center justify-center">
                      <i className="fas fa-map-marker-alt text-xl"></i>
                    </div>
                    <span>123 Global Plaza, Education Row, Suite 500</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-800 rounded-full flex items-center justify-center">
                      <i className="fas fa-phone-alt text-xl"></i>
                    </div>
                    <span>+1 (800) LEAD-WISE</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-800 rounded-full flex items-center justify-center">
                      <i className="fas fa-envelope text-xl"></i>
                    </div>
                    <span>consult@leadwise-edu.com</span>
                  </div>
                </div>
              </div>
              <div className="bg-white p-8 rounded-2xl text-slate-900 shadow-2xl">
                <ContactForm />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* AI Floating Button */}
      <button 
        onClick={() => setIsCounselorOpen(true)}
        className="fixed bottom-8 right-8 w-16 h-16 bg-blue-600 text-white rounded-full shadow-2xl hover:bg-blue-700 transition-all z-40 flex items-center justify-center animate-bounce hover:animate-none"
      >
        <i className="fas fa-robot text-2xl"></i>
      </button>

      {/* AI Side Panel */}
      {isCounselorOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsCounselorOpen(false)}></div>
          <div className="absolute inset-y-0 right-0 max-w-md w-full bg-white shadow-2xl flex flex-col">
            <div className="p-6 border-b flex justify-between items-center bg-blue-900 text-white">
              <div className="flex items-center gap-3">
                <i className="fas fa-graduation-cap text-2xl"></i>
                <h3 className="text-xl font-bold">AI Education Counselor</h3>
              </div>
              <button onClick={() => setIsCounselorOpen(false)} className="hover:text-blue-200 transition-colors">
                <i className="fas fa-times text-2xl"></i>
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <AICounselor />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
