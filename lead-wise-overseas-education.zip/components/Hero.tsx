
import React from 'react';

interface HeroProps {
  onCtaClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onCtaClick }) => {
  return (
    <div className="relative bg-blue-950 text-white overflow-hidden min-h-[85vh] flex items-center">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M0 0 L100 0 L100 100 L0 100 Z" fill="url(#grad)" />
          <defs>
            <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#1e3a8a', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10 py-20 lg:py-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-block px-4 py-1.5 bg-blue-600/20 border border-blue-400/30 rounded-full">
              <span className="text-blue-400 font-bold tracking-wider text-sm uppercase">Empowering Your Future</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-extrabold leading-tight">
              Unlock Your <span className="text-blue-500">Global Potential</span> with Expert Guidance
            </h1>
            <p className="text-xl text-slate-300 max-w-lg">
              Navigate the complexities of overseas education with Lead-Wise. From university selection to visa approval, we're with you at every step.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={onCtaClick}
                className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-xl shadow-blue-900/40 flex items-center justify-center gap-2"
              >
                <i className="fas fa-paper-plane"></i>
                Start Your Journey Now
              </button>
              <a 
                href="#services"
                className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl border border-white/20 transition-all flex items-center justify-center gap-2 backdrop-blur-sm"
              >
                Learn More
              </a>
            </div>
            <div className="flex items-center gap-4 text-slate-400">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map(i => (
                  <img key={i} src={`https://picsum.photos/seed/${i + 10}/100/100`} className="w-10 h-10 rounded-full border-2 border-blue-900" alt="Student" />
                ))}
              </div>
              <p className="text-sm">Trusted by 5,000+ Students worldwide</p>
            </div>
          </div>
          
          <div className="relative lg:block hidden">
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-700">
              <img 
                src="https://picsum.photos/seed/edu/800/600" 
                alt="Student Abroad" 
                className="w-full h-auto object-cover"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-blue-500/20 blur-3xl rounded-full"></div>
            <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-blue-800/30 blur-2xl rounded-full"></div>
            <div className="absolute top-1/2 -left-8 bg-white p-4 rounded-2xl shadow-xl transform -translate-y-1/2 text-slate-900 flex items-center gap-4 z-20 animate-bounce">
              <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                <i className="fas fa-check-circle text-2xl"></i>
              </div>
              <div>
                <p className="font-bold">98% Success Rate</p>
                <p className="text-xs text-slate-500">Visa Approvals 2024</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
