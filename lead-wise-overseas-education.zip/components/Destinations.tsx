
import React from 'react';
import { Destination } from '../types';

const destinations: Destination[] = [
  {
    id: 'usa',
    country: 'United States',
    description: 'Home to the world’s most prestigious Ivy League universities and high research potential.',
    imageUrl: 'https://picsum.photos/seed/nyc/600/400',
    stats: { universities: 4000, avgFee: '$20,000/yr', intake: 'Sept / Jan' }
  },
  {
    id: 'uk',
    country: 'United Kingdom',
    description: 'A rich heritage of academic excellence with 1-year Master’s programs and 2-year post-study work visa.',
    imageUrl: 'https://picsum.photos/seed/london/600/400',
    stats: { universities: 160, avgFee: '£15,000/yr', intake: 'Sept / Jan' }
  },
  {
    id: 'can',
    country: 'Canada',
    description: 'Friendly immigration policies, high quality of life, and affordable world-class education.',
    imageUrl: 'https://picsum.photos/seed/toronto/600/400',
    stats: { universities: 100, avgFee: 'CAD 25k/yr', intake: 'Sept / Jan / May' }
  },
  {
    id: 'aus',
    country: 'Australia',
    description: 'Stunning lifestyle combined with top-ranked universities and great part-time work opportunities.',
    imageUrl: 'https://picsum.photos/seed/sydney/600/400',
    stats: { universities: 43, avgFee: 'AUD 30k/yr', intake: 'Feb / July' }
  }
];

const Destinations: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {destinations.map((dest) => (
        <div key={dest.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-slate-100 flex flex-col h-full">
          <div className="relative h-48 overflow-hidden">
            <img src={dest.imageUrl} alt={dest.country} className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-500" />
            <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-blue-900 uppercase">
              Limited Seats
            </div>
          </div>
          <div className="p-6 flex-1 flex flex-col">
            <h3 className="text-xl font-bold text-slate-900 mb-2">{dest.country}</h3>
            <p className="text-sm text-slate-600 mb-6 line-clamp-2">{dest.description}</p>
            <div className="mt-auto pt-4 border-t border-slate-50 grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase">Unis</p>
                <p className="text-sm font-bold text-blue-600">{dest.stats.universities}+</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase">Avg Fee</p>
                <p className="text-sm font-bold text-blue-600">{dest.stats.avgFee}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase">Intake</p>
                <p className="text-xs font-bold text-blue-600">{dest.stats.intake.split(' / ')[0]}</p>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Destinations;
