
import React from 'react';
import { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Jenkins',
    university: 'Oxford University, UK',
    content: "Lead-Wise made the impossible possible. Their SOP editing was a game-changer for my application. I'm now pursuing my dream Master's thanks to them!",
    imageUrl: 'https://picsum.photos/seed/sarah/100/100'
  },
  {
    id: '2',
    name: 'Rahul Sharma',
    university: 'Stanford University, USA',
    content: "The visa process was so daunting, but Lead-Wise's documentation team was flawless. They handled every detail with extreme precision.",
    imageUrl: 'https://picsum.photos/seed/rahul/100/100'
  },
  {
    id: '3',
    name: 'Aisha Chen',
    university: 'University of Toronto, Canada',
    content: "From IELTS coaching to finding my accommodation in Toronto, Lead-Wise was there. Truly a comprehensive service for international students.",
    imageUrl: 'https://picsum.photos/seed/aisha/100/100'
  }
];

const Testimonials: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-extrabold text-blue-900 mb-4">Student Success Stories</h2>
        <p className="text-slate-600 max-w-2xl mx-auto">Hear from our students who are now studying at top-tier universities across the globe.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {testimonials.map((t) => (
          <div key={t.id} className="bg-gray-50 p-8 rounded-3xl relative">
            <div className="text-blue-200 absolute top-6 right-8 text-6xl opacity-50">
              <i className="fas fa-quote-right"></i>
            </div>
            <div className="flex items-center gap-4 mb-6">
              <img src={t.imageUrl} alt={t.name} className="w-16 h-16 rounded-full border-4 border-white shadow-md" />
              <div>
                <h4 className="font-bold text-slate-900">{t.name}</h4>
                <p className="text-sm text-blue-600 font-medium">{t.university}</p>
              </div>
            </div>
            <p className="text-slate-600 italic leading-relaxed">"{t.content}"</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Testimonials;
