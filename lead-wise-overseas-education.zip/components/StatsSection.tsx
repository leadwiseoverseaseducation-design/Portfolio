
import React from 'react';

const StatsSection: React.FC = () => {
  const stats = [
    { label: 'Students Placed', value: '15,000+', icon: 'fa-user-graduate' },
    { label: 'Global Partners', value: '800+', icon: 'fa-handshake' },
    { label: 'Visa Success', value: '99%', icon: 'fa-file-signature' },
    { label: 'Countries Served', value: '25+', icon: 'fa-globe' },
  ];

  return (
    <div className="bg-white py-12 border-b">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, idx) => (
            <div key={idx} className="text-center group">
              <div className="text-3xl text-blue-100 group-hover:text-blue-500 transition-colors mb-2">
                <i className={`fas ${stat.icon}`}></i>
              </div>
              <p className="text-4xl font-black text-blue-900 mb-1">{stat.value}</p>
              <p className="text-slate-500 font-medium text-sm tracking-wide uppercase">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatsSection;
