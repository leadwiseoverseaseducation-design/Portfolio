
import React from 'react';
import { Service } from '../types';

const services: Service[] = [
  {
    id: '1',
    title: 'University Selection',
    description: 'We help you find the perfect university that matches your academic profile, budget, and career goals.',
    icon: 'fa-university'
  },
  {
    id: '2',
    title: 'Visa Assistance',
    description: 'Our documentation experts ensure a high success rate with meticulous visa application guidance.',
    icon: 'fa-passport'
  },
  {
    id: '3',
    title: 'Test Preparation',
    description: 'Intensive coaching for IELTS, TOEFL, GRE, GMAT, and SAT to help you secure top scores.',
    icon: 'fa-book-open'
  },
  {
    id: '4',
    title: 'Scholarship Guidance',
    description: 'Identify and apply for internal, external, and government scholarships to ease your financial burden.',
    icon: 'fa-graduation-cap'
  },
  {
    id: '5',
    title: 'SOP & LOR Editing',
    description: 'Expert feedback on your Statement of Purpose and Letters of Recommendation to stand out to admissions.',
    icon: 'fa-edit'
  },
  {
    id: '6',
    title: 'Post-Arrival Support',
    description: 'From airport pickup to finding accommodation, we support you even after you reach your destination.',
    icon: 'fa-plane-arrival'
  }
];

const Services: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {services.map((service) => (
        <div key={service.id} className="p-8 bg-white border border-slate-100 rounded-2xl hover:shadow-xl hover:-translate-y-1 transition-all group">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
            <i className={`fas ${service.icon} text-3xl`}></i>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
          <p className="text-slate-600 leading-relaxed">{service.description}</p>
        </div>
      ))}
    </div>
  );
};

export default Services;
