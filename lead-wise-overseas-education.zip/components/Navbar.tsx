
import React, { useState } from 'react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md shadow-sm border-b">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-blue-900 rounded-lg flex items-center justify-center">
            <i className="fas fa-globe-americas text-white text-xl"></i>
          </div>
          <span className="text-2xl font-black text-blue-900 tracking-tight">
            LEAD-WISE
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          <a href="#services" className="font-medium text-slate-600 hover:text-blue-600 transition-colors">Services</a>
          <a href="#destinations" className="font-medium text-slate-600 hover:text-blue-600 transition-colors">Destinations</a>
          <a href="#testimonials" className="font-medium text-slate-600 hover:text-blue-600 transition-colors">Success Stories</a>
          <a href="#contact" className="bg-blue-600 text-white px-6 py-2 rounded-full font-bold hover:bg-blue-700 transition-all shadow-md">
            Get Expert Advice
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-slate-600">
          <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'} text-2xl`}></i>
        </button>
      </div>

      {/* Mobile Nav Overlay */}
      {isOpen && (
        <div className="md:hidden bg-white border-t p-4 space-y-4 shadow-lg animate-in slide-in-from-top">
          <a href="#services" onClick={() => setIsOpen(false)} className="block py-2 text-lg font-medium text-slate-700">Services</a>
          <a href="#destinations" onClick={() => setIsOpen(false)} className="block py-2 text-lg font-medium text-slate-700">Destinations</a>
          <a href="#testimonials" onClick={() => setIsOpen(false)} className="block py-2 text-lg font-medium text-slate-700">Success Stories</a>
          <a href="#contact" onClick={() => setIsOpen(false)} className="block py-3 text-center bg-blue-600 text-white rounded-lg font-bold">Contact Us</a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
