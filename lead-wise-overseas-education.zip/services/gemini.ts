
import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are the "Lead-Wise AI Education Counselor", a friendly, professional, and highly knowledgeable assistant for Lead-Wise Overseas Education.
Your goal is to help students explore study abroad options. 

Guidelines:
1. Provide accurate information about studying in USA, UK, Canada, Australia, Germany, and Ireland.
2. Ask clarifying questions: What is their current education? Which country do they prefer? What is their budget?
3. Mention Lead-Wise services: University selection, Visa assistance, Test prep (IELTS/GRE), and Scholarships.
4. Keep responses concise and use bullet points for readability.
5. If you don't know something, suggest they speak with a human consultant at +1 (800) LEAD-WISE.
6. Always maintain an encouraging and supportive tone.
`;

export const getCounselorResponse = async (chatHistory: Message[]) => {
  try {
    const formattedHistory = chatHistory.map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    // Use gemini-3-flash-preview for fast and smart responses
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: formattedHistory.map(h => ({ role: h.role as any, parts: h.parts })),
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topP: 0.95,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having a little trouble connecting to my knowledge base. Please try again or call our office directly!";
  }
};
