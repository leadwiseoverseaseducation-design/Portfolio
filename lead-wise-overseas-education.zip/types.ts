
export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface Destination {
  id: string;
  country: string;
  description: string;
  imageUrl: string;
  stats: {
    universities: number;
    avgFee: string;
    intake: string;
  };
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export interface Testimonial {
  id: string;
  name: string;
  university: string;
  content: string;
  imageUrl: string;
}
