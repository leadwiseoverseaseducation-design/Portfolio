import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Phone, BookOpen, Plane } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ProcessSectionProps {
  className?: string;
}

const ProcessSection = ({ className = '' }: ProcessSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const photoRef = useRef<HTMLDivElement>(null);
  const stepsRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Photo animation
      gsap.fromTo(
        photoRef.current,
        { x: '-12vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 45%',
            scrub: 1,
          },
        }
      );

      // Steps animation
      const steps = stepsRef.current?.querySelectorAll('.process-step');
      if (steps) {
        gsap.fromTo(
          steps,
          { y: 24, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            stagger: 0.12,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: stepsRef.current,
              start: 'top 85%',
              end: 'top 50%',
              scrub: 1,
            },
          }
        );
      }

      // Timeline card animation
      gsap.fromTo(
        timelineRef.current,
        { y: '10vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            end: 'top 30%',
            scrub: 1,
          },
        }
      );

      // Timeline dots animation
      const dots = timelineRef.current?.querySelectorAll('.timeline-dot');
      if (dots) {
        gsap.fromTo(
          dots,
          { scale: 0 },
          {
            scale: 1,
            stagger: 0.1,
            duration: 0.5,
            ease: 'back.out(1.7)',
            scrollTrigger: {
              trigger: timelineRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const steps = [
    {
      number: '01',
      title: 'Discovery call',
      description: 'We map your goals, budget, and timeline.',
      icon: Phone,
    },
    {
      number: '02',
      title: 'Prep + shortlist',
      description: 'Test coaching + university shortlist with real admit data.',
      icon: BookOpen,
    },
    {
      number: '03',
      title: 'Apply + depart',
      description: 'Applications, visa, loans, and pre-departure briefings.',
      icon: Plane,
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="process"
      className={`section-flowing bg-[#F6F6F2] ${className}`}
    >
      {/* Diagonal band decoration */}
      <div className="absolute left-0 top-0 w-1/3 h-full opacity-5">
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="w-full h-full"
        >
          <polygon points="0,0 100,0 60,100 0,100" fill="#0B1E2F" />
        </svg>
      </div>

      <div className="relative px-6 lg:px-[6vw]">
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          {/* Left photo card */}
          <div
            ref={photoRef}
            className="w-full lg:w-[40%] card-large overflow-hidden shadow-lg"
            style={{ height: 'clamp(300px, 50vh, 500px)' }}
          >
            <img
              src="/process_planning.jpg"
              alt="Student planning"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Right steps block */}
          <div
            ref={stepsRef}
            className="w-full lg:w-[50%] flex flex-col justify-center py-8"
          >
            <span className="font-mono-label text-[#6B7885] mb-4">
              HOW IT WORKS
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-[#0B1E2F] mb-8">
              Plan. Prepare. Fly.
            </h2>

            <div className="space-y-8">
              {steps.map((step, index) => (
                <div
                  key={index}
                  className="process-step flex items-start gap-4 p-4 rounded-2xl bg-white border border-[#0B1E2F]/10 hover:border-[#C8FF2E] transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-[#C8FF2E] flex items-center justify-center flex-shrink-0">
                    <step.icon className="w-6 h-6 text-[#0B1E2F]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="font-mono-label text-[#6B7885]">
                        {step.number}
                      </span>
                      <h3 className="font-display text-xl font-bold text-[#0B1E2F]">
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-[#6B7885] text-sm lg:text-base">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Timeline accent card */}
        <div
          ref={timelineRef}
          className="mt-8 lg:mt-12 w-full lg:w-[40%] card-medium bg-lime p-6 lg:p-8"
        >
          <p className="text-[#0B1E2F] font-medium mb-4">
            Typical timeline: 3–6 months
          </p>
          <div className="flex items-center gap-4">
            <div className="timeline-dot w-4 h-4 rounded-full bg-[#0B1E2F]" />
            <div className="flex-1 h-1 bg-[#0B1E2F]/20 rounded-full">
              <div className="w-1/3 h-full bg-[#0B1E2F] rounded-full" />
            </div>
            <div className="timeline-dot w-4 h-4 rounded-full bg-[#0B1E2F]/40" />
            <div className="flex-1 h-1 bg-[#0B1E2F]/20 rounded-full" />
            <div className="timeline-dot w-4 h-4 rounded-full bg-[#0B1E2F]/20" />
          </div>
          <div className="flex justify-between mt-2 text-xs text-[#0B1E2F]/70">
            <span>Month 1</span>
            <span>Month 3</span>
            <span>Month 6</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
