import { Instagram, Linkedin, Youtube, MessageCircle } from 'lucide-react';

interface FooterProps {
  className?: string;
}

const Footer = ({ className = '' }: FooterProps) => {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const links = {
    services: [
      { label: 'Test Prep', href: '#services' },
      { label: 'Counseling', href: '#services' },
      { label: 'Visa Support', href: '#services' },
    ],
    destinations: [
      { label: 'UK', href: '#destinations' },
      { label: 'USA', href: '#destinations' },
      { label: 'Canada', href: '#destinations' },
      { label: 'Australia', href: '#destinations' },
    ],
    company: [
      { label: 'About Us', href: '#why' },
      { label: 'Results', href: '#results' },
      { label: 'Blog', href: '#blog' },
      { label: 'Contact', href: '#contact' },
    ],
    legal: [
      { label: 'Privacy Policy', href: '#' },
      { label: 'Terms of Service', href: '#' },
    ],
  };

  const socialLinks = [
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Youtube, href: '#', label: 'YouTube' },
    { icon: MessageCircle, href: '#', label: 'WhatsApp' },
  ];

  return (
    <footer className={`bg-[#F6F6F2] border-t border-[#0B1E2F]/10 ${className}`}>
      <div className="px-6 lg:px-[6vw] py-12 lg:py-16">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          {/* Left column - Brand */}
          <div className="w-full lg:w-1/3">
            <a
              href="#"
              className="font-display text-2xl font-bold text-[#0B1E2F] mb-4 block"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              Lead-Wise
            </a>
            <p className="text-[#6B7885] text-sm lg:text-base leading-relaxed mb-6">
              Coaching + counseling for students who want more than guesswork.
            </p>
            
            {/* Contact info */}
            <div className="space-y-2 mb-6">
              <a
                href="mailto:hello@leadwise.education"
                className="block text-[#0B1E2F] text-sm hover:underline"
              >
                hello@leadwise.education
              </a>
              <a
                href="tel:+91XXXXXXXXXX"
                className="block text-[#0B1E2F] text-sm hover:underline"
              >
                +91-XXXXX-XXXXX
              </a>
            </div>

            {/* Social links */}
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full bg-[#0B1E2F] flex items-center justify-center hover:bg-[#C8FF2E] hover:text-[#0B1E2F] text-white transition-colors"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Right columns - Links */}
          <div className="w-full lg:w-2/3 grid grid-cols-2 md:grid-cols-4 gap-8">
            {/* Services */}
            <div>
              <h4 className="font-display font-semibold text-[#0B1E2F] mb-4">
                Services
              </h4>
              <ul className="space-y-2">
                {links.services.map((link, index) => (
                  <li key={index}>
                    <button
                      onClick={() => scrollToSection(link.href)}
                      className="text-[#6B7885] text-sm hover:text-[#0B1E2F] transition-colors"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Destinations */}
            <div>
              <h4 className="font-display font-semibold text-[#0B1E2F] mb-4">
                Destinations
              </h4>
              <ul className="space-y-2">
                {links.destinations.map((link, index) => (
                  <li key={index}>
                    <button
                      onClick={() => scrollToSection(link.href)}
                      className="text-[#6B7885] text-sm hover:text-[#0B1E2F] transition-colors"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-display font-semibold text-[#0B1E2F] mb-4">
                Company
              </h4>
              <ul className="space-y-2">
                {links.company.map((link, index) => (
                  <li key={index}>
                    <button
                      onClick={() => scrollToSection(link.href)}
                      className="text-[#6B7885] text-sm hover:text-[#0B1E2F] transition-colors"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-display font-semibold text-[#0B1E2F] mb-4">
                Legal
              </h4>
              <ul className="space-y-2">
                {links.legal.map((link, index) => (
                  <li key={index}>
                    <button
                      onClick={() => scrollToSection(link.href)}
                      className="text-[#6B7885] text-sm hover:text-[#0B1E2F] transition-colors"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-[#0B1E2F]/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[#6B7885] text-sm">
            © {new Date().getFullYear()} Lead-Wise Overseas Education. All rights
            reserved.
          </p>
          <p className="text-[#6B7885] text-xs">
            Designed with care for students worldwide.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
