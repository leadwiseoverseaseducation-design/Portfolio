import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, BookOpen, FileText, Plane } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ServicesSectionProps {
  className?: string;
}

const ServicesSection = ({ className = '' }: ServicesSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardARef = useRef<HTMLDivElement>(null);
  const cardBRef = useRef<HTMLDivElement>(null);
  const cardCRef = useRef<HTMLDivElement>(null);
  const cardDRef = useRef<HTMLDivElement>(null);
  const blobRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        cardARef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardDRef.current,
        { x: '60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardBRef.current,
        { x: '60vw', y: '-20vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardCRef.current,
        { x: '-60vw', y: '20vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0
      );

      // SETTLE (30%-70%): Hold positions

      // EXIT (70%-100%)
      scrollTl.fromTo(
        cardARef.current,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardDRef.current,
        { y: 0, opacity: 1 },
        { y: '18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardBRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardCRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  // Blob rotation
  useLayoutEffect(() => {
    if (blobRef.current) {
      gsap.to(blobRef.current, {
        rotation: 8,
        duration: 12,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className={`section-pinned bg-[#F6F6F2] flex items-center justify-center ${className}`}
    >
      {/* Background blob */}
      <div
        ref={blobRef}
        className="blob w-[60vw] h-[60vh] bg-[#C8FF2E]/20 left-[10%] top-[20%]"
      />

      {/* Mosaic container */}
      <div className="relative w-[90vw] lg:w-[88vw] h-[85vh] lg:h-[80vh]">
        {/* Card A - Top-left (accent) */}
        <div
          ref={cardARef}
          className="absolute card-large bg-lime p-6 lg:p-10 flex flex-col justify-center"
          style={{
            left: '0',
            top: '0',
            width: '100%',
            height: '30%',
          }}
        >
          <BookOpen className="w-8 h-8 text-[#0B1E2F] mb-4" />
          <h3 className="font-display text-2xl lg:text-3xl font-bold text-[#0B1E2F] mb-3">
            Test prep that adapts to you.
          </h3>
          <p className="text-[#0B1E2F]/80 text-sm lg:text-base mb-4">
            IELTS · TOEFL · PTE · GRE · GMAT. Live sessions, practice tests,
            and feedback loops built around your weak areas.
          </p>
          <button className="inline-flex items-center text-[#0B1E2F] font-medium text-sm hover:underline w-fit">
            See coaching plans
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>

        {/* Card B - Top-right (image) */}
        <div
          ref={cardBRef}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            left: '0',
            top: '32%',
            width: '100%',
            height: '30%',
          }}
        >
          <img
            src="/services_classroom.jpg"
            alt="Classroom coaching session"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Card C - Bottom-left (image) */}
        <div
          ref={cardCRef}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            left: '0',
            top: '64%',
            width: '48%',
            height: '34%',
          }}
        >
          <img
            src="/services_mentor.jpg"
            alt="Mentor guiding student"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Card D - Bottom-right (accent) */}
        <div
          ref={cardDRef}
          className="absolute card-large bg-lime p-6 lg:p-8 flex flex-col justify-center"
          style={{
            right: '0',
            top: '64%',
            width: '50%',
            height: '34%',
          }}
        >
          <FileText className="w-8 h-8 text-[#0B1E2F] mb-3" />
          <h3 className="font-display text-xl lg:text-2xl font-bold text-[#0B1E2F] mb-2">
            End-to-end counseling.
          </h3>
          <p className="text-[#0B1E2F]/80 text-xs lg:text-sm mb-3">
            Shortlisting · Applications · SOPs · LORs · Visa · Loans ·
            Accommodation.
          </p>
          <button className="inline-flex items-center text-[#0B1E2F] font-medium text-sm hover:underline w-fit">
            View services
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>

        {/* Floating icon chip */}
        <div
          className="absolute w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center"
          style={{ right: '5%', top: '28%' }}
        >
          <Plane className="w-6 h-6 text-[#0B1E2F]" />
        </div>
      </div>

      {/* Desktop layout adjustments */}
      <style>{`
        @media (min-width: 1024px) {
          .section-pinned > div:nth-child(2) > div:nth-child(2) {
            width: 48% !important;
            height: 46% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(3) {
            left: 52% !important;
            top: 0 !important;
            width: 48% !important;
            height: 46% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(4) {
            width: 48% !important;
            height: 50% !important;
            top: 50% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(5) {
            width: 50% !important;
            height: 50% !important;
            top: 50% !important;
          }
        }
      `}</style>
    </section>
  );
};

export default ServicesSection;
