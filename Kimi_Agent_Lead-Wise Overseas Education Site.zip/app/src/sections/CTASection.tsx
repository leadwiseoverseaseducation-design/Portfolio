import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Phone, Send, MessageCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface CTASectionProps {
  className?: string;
}

const CTASection = ({ className = '' }: CTASectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    target: '',
    time: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=120%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        textRef.current,
        { x: '-30vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        formRef.current,
        { x: '40vw', opacity: 0, scale: 0.98 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // Form fields stagger
      const fields = formRef.current?.querySelectorAll('.form-field');
      if (fields) {
        scrollTl.fromTo(
          fields,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.04, ease: 'none' },
          0.15
        );
      }

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        formRef.current,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        textRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className={`section-pinned bg-[#0B1E2F] flex items-center justify-center ${className}`}
    >
      {/* Grain overlay for this section */}
      <div className="absolute inset-0 opacity-5">
        <svg
          viewBox="0 0 256 256"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
        >
          <filter id="noise">
            <feTurbulence
              type="fractalNoise"
              baseFrequency="0.85"
              numOctaves="4"
              stitchTiles="stitch"
            />
          </filter>
          <rect width="100%" height="100%" filter="url(#noise)" />
        </svg>
      </div>

      <div className="relative w-[90vw] lg:w-[88vw] flex flex-col lg:flex-row gap-8 lg:gap-12 items-center">
        {/* Left text block */}
        <div
          ref={textRef}
          className="w-full lg:w-[45%] text-white"
        >
          <span className="font-mono-label text-white/50 mb-4 block">
            BOOK A FREE CALL
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Ready when you are.
          </h2>
          <p className="text-white/70 text-base lg:text-lg leading-relaxed mb-8">
            Tell us what you're aiming for. We'll reply within 24 hours with a
            plan.
          </p>
          <div className="flex items-center gap-3 text-white/50 text-sm">
            <div className="w-2 h-2 rounded-full bg-[#C8FF2E]" />
            No spam. No pressure. Just a clear next step.
          </div>
        </div>

        {/* Right form card */}
        <div
          ref={formRef}
          className="w-full lg:w-[50%] card-large bg-[#C8FF2E] p-6 lg:p-10"
        >
          {isSubmitted ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-[#0B1E2F] flex items-center justify-center mx-auto mb-4">
                <Send className="w-8 h-8 text-[#C8FF2E]" />
              </div>
              <h3 className="font-display text-2xl font-bold text-[#0B1E2F] mb-2">
                Request received!
              </h3>
              <p className="text-[#0B1E2F]/70">
                We'll get back to you within 24 hours.
              </p>
            </div>
          ) : (
            <>
              <h3 className="font-display text-xl lg:text-2xl font-bold text-[#0B1E2F] mb-6">
                Request a callback
              </h3>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="form-field">
                  <label className="block text-sm font-medium text-[#0B1E2F] mb-1">
                    Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#0B1E2F]/20 bg-white text-[#0B1E2F] focus:border-[#0B1E2F] focus:outline-none transition-colors"
                    placeholder="Your full name"
                  />
                </div>

                <div className="form-field">
                  <label className="block text-sm font-medium text-[#0B1E2F] mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#0B1E2F]/20 bg-white text-[#0B1E2F] focus:border-[#0B1E2F] focus:outline-none transition-colors"
                    placeholder="your@email.com"
                  />
                </div>

                <div className="form-field">
                  <label className="block text-sm font-medium text-[#0B1E2F] mb-1">
                    Phone
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#0B1E2F]/20 bg-white text-[#0B1E2F] focus:border-[#0B1E2F] focus:outline-none transition-colors"
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>

                <div className="form-field">
                  <label className="block text-sm font-medium text-[#0B1E2F] mb-1">
                    Target country/course
                  </label>
                  <input
                    type="text"
                    name="target"
                    value={formData.target}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#0B1E2F]/20 bg-white text-[#0B1E2F] focus:border-[#0B1E2F] focus:outline-none transition-colors"
                    placeholder="e.g., MS in Computer Science, USA"
                  />
                </div>

                <div className="form-field">
                  <label className="block text-sm font-medium text-[#0B1E2F] mb-1">
                    Preferred time
                  </label>
                  <select
                    name="time"
                    value={formData.time}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#0B1E2F]/20 bg-white text-[#0B1E2F] focus:border-[#0B1E2F] focus:outline-none transition-colors"
                  >
                    <option value="">Select a time</option>
                    <option value="morning">Morning (9 AM - 12 PM)</option>
                    <option value="afternoon">Afternoon (12 PM - 5 PM)</option>
                    <option value="evening">Evening (5 PM - 8 PM)</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="form-field w-full btn-primary py-4 text-base font-semibold"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Book my free call
                </button>
              </form>

              <div className="mt-4 flex items-center justify-center gap-2 text-[#0B1E2F]/70 text-sm">
                <MessageCircle className="w-4 h-4" />
                <span>Prefer WhatsApp? Message +91-XXXXX-XXXXX</span>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default CTASection;
