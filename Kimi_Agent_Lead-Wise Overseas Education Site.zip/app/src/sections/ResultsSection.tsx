import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Trophy, Users, GraduationCap, Award } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ResultsSectionProps {
  className?: string;
}

const ResultsSection = ({ className = '' }: ResultsSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardR1Ref = useRef<HTMLDivElement>(null);
  const cardR2Ref = useRef<HTMLDivElement>(null);
  const cardR3Ref = useRef<HTMLDivElement>(null);
  const cardR4Ref = useRef<HTMLDivElement>(null);
  const blobRef = useRef<HTMLDivElement>(null);
  
  const [counts, setCounts] = useState({ students: 0, admits: 0, visa: 0 });

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onEnter: () => {
            // Animate counters when section enters
            animateCounters();
          },
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        cardR1Ref.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardR4Ref.current,
        { x: '60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardR2Ref.current,
        { x: '40vw', y: '-30vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardR3Ref.current,
        { x: '-40vw', y: '30vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0
      );

      // Trophy chip
      const trophyChip = section.querySelector('.trophy-chip');
      if (trophyChip) {
        scrollTl.fromTo(
          trophyChip,
          { scale: 0.5, opacity: 0 },
          { scale: 1, opacity: 1, ease: 'none' },
          0.2
        );
      }

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        cardR1Ref.current,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardR4Ref.current,
        { y: 0, opacity: 1 },
        { y: '18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardR2Ref.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardR3Ref.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  // Blob rotation
  useLayoutEffect(() => {
    if (blobRef.current) {
      gsap.to(blobRef.current, {
        rotation: 8,
        duration: 12,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }
  }, []);

  const animateCounters = () => {
    const duration = 2000;
    const steps = 60;
    const interval = duration / steps;
    
    let step = 0;
    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
      
      setCounts({
        students: Math.round(1200 * eased),
        admits: Math.round(850 * eased),
        visa: Math.round(94 * eased),
      });
      
      if (step >= steps) clearInterval(timer);
    }, interval);
  };

  const stats = [
    { value: counts.students, suffix: '+', label: 'students coached', icon: Users },
    { value: counts.admits, suffix: '+', label: 'admits secured', icon: GraduationCap },
    { value: counts.visa, suffix: '%', label: 'visa success rate', icon: Award },
  ];

  return (
    <section
      ref={sectionRef}
      id="results"
      className={`section-pinned bg-[#F6F6F2] flex items-center justify-center ${className}`}
    >
      {/* Background blob */}
      <div
        ref={blobRef}
        className="blob w-[55vw] h-[55vh] bg-[#C8FF2E]/20 left-[15%] top-[20%]"
      />

      {/* Collage container */}
      <div className="relative w-[90vw] lg:w-[86vw] h-[85vh] lg:h-[80vh]">
        {/* Card R1 - Top-left (accent) */}
        <div
          ref={cardR1Ref}
          className="absolute card-large bg-lime p-6 lg:p-10 flex flex-col justify-center"
          style={{
            left: '0',
            top: '0',
            width: '100%',
            height: '30%',
          }}
        >
          <h3 className="font-display text-2xl lg:text-3xl font-bold text-[#0B1E2F] mb-3">
            Numbers that matter.
          </h3>
          <p className="text-[#0B1E2F]/80 text-sm lg:text-base">
            Admits aren't luck—they're the result of disciplined prep and
            precise applications.
          </p>
        </div>

        {/* Card R2 - Top-right (image) */}
        <div
          ref={cardR2Ref}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            left: '0',
            top: '32%',
            width: '100%',
            height: '30%',
          }}
        >
          <img
            src="/results_classroom.jpg"
            alt="Classroom session"
            className="w-full h-full object-cover"
          />
          {/* Trophy chip */}
          <div className="trophy-chip absolute top-4 right-4 w-10 h-10 rounded-full bg-[#C8FF2E] flex items-center justify-center shadow-lg">
            <Trophy className="w-5 h-5 text-[#0B1E2F]" />
          </div>
        </div>

        {/* Card R3 - Bottom-left (image) */}
        <div
          ref={cardR3Ref}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            left: '0',
            top: '64%',
            width: '48%',
            height: '34%',
          }}
        >
          <img
            src="/results_mentor.jpg"
            alt="Mentor close-up"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Card R4 - Bottom-right (accent with stats) */}
        <div
          ref={cardR4Ref}
          className="absolute card-large bg-lime p-6 lg:p-8 flex flex-col justify-center"
          style={{
            right: '0',
            top: '64%',
            width: '50%',
            height: '34%',
          }}
        >
          <div className="grid grid-cols-3 gap-2 lg:gap-4">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="w-5 h-5 lg:w-6 lg:h-6 text-[#0B1E2F] mx-auto mb-1 lg:mb-2" />
                <div className="font-display text-xl lg:text-2xl xl:text-3xl font-bold text-[#0B1E2F]">
                  {stat.value}{stat.suffix}
                </div>
                <div className="text-[10px] lg:text-xs text-[#0B1E2F]/70 mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
          <button className="inline-flex items-center text-[#0B1E2F] font-medium text-sm hover:underline mt-4 w-fit">
            See latest admits
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>
      </div>

      {/* Desktop layout adjustments */}
      <style>{`
        @media (min-width: 1024px) {
          .section-pinned > div:nth-child(2) > div:nth-child(2) {
            width: 48% !important;
            height: 46% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(3) {
            left: 52% !important;
            top: 0 !important;
            width: 48% !important;
            height: 46% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(4) {
            width: 48% !important;
            height: 50% !important;
            top: 50% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(5) {
            width: 50% !important;
            height: 50% !important;
            top: 50% !important;
          }
        }
      `}</style>
    </section>
  );
};

export default ResultsSection;
