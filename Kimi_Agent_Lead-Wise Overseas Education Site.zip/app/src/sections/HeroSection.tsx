import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, MapPin } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  className?: string;
}

const HeroSection = ({ className = '' }: HeroSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const card1Ref = useRef<HTMLDivElement>(null);
  const card2Ref = useRef<HTMLDivElement>(null);
  const card3Ref = useRef<HTMLDivElement>(null);
  const card4Ref = useRef<HTMLDivElement>(null);
  const blobRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Card 1 (photo) from left
      tl.fromTo(
        card1Ref.current,
        { x: '-60vw', opacity: 0, scale: 0.96 },
        { x: 0, opacity: 1, scale: 1, duration: 1 },
        0
      );

      // Card 4 (photo) from right
      tl.fromTo(
        card4Ref.current,
        { x: '60vw', opacity: 0, scale: 0.96 },
        { x: 0, opacity: 1, scale: 1, duration: 1 },
        0
      );

      // Card 2 (text) from top
      tl.fromTo(
        card2Ref.current,
        { y: '-40vh', opacity: 0 },
        { y: 0, opacity: 1, duration: 0.9 },
        0.15
      );

      // Card 3 (text) from bottom
      tl.fromTo(
        card3Ref.current,
        { y: '40vh', opacity: 0 },
        { y: 0, opacity: 1, duration: 0.9 },
        0.15
      );

      // Headline words stagger
      const headlineWords = card2Ref.current?.querySelectorAll('.headline-word');
      if (headlineWords) {
        tl.fromTo(
          headlineWords,
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, duration: 0.5 },
          0.4
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back
            gsap.set([card1Ref.current, card2Ref.current, card3Ref.current, card4Ref.current], {
              opacity: 1,
              x: 0,
              y: 0,
              scale: 1,
            });
          },
        },
      });

      // ENTRANCE (0%-30%): Hold at settle state
      // SETTLE (30%-70%): Stable viewing
      // EXIT (70%-100%): Elements drift out

      // Card 2 (top-right text) exits up
      scrollTl.fromTo(
        card2Ref.current,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      // Card 3 (bottom-left text) exits down
      scrollTl.fromTo(
        card3Ref.current,
        { y: 0, opacity: 1 },
        { y: '18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      // Card 1 (top-left photo) exits left
      scrollTl.fromTo(
        card1Ref.current,
        { x: 0, scale: 1, opacity: 1 },
        { x: '-22vw', scale: 0.98, opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      // Card 4 (bottom-right photo) exits right
      scrollTl.fromTo(
        card4Ref.current,
        { x: 0, scale: 1, opacity: 1 },
        { x: '22vw', scale: 0.98, opacity: 0.35, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  // Blob rotation animation
  useEffect(() => {
    if (blobRef.current) {
      gsap.to(blobRef.current, {
        rotation: 8,
        duration: 12,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className={`section-pinned bg-[#F6F6F2] flex items-center justify-center ${className}`}
    >
      {/* Background blob */}
      <div
        ref={blobRef}
        className="blob w-[70vw] h-[70vh] bg-[#C8FF2E]/20 -translate-x-1/2 -translate-y-1/2 left-1/2 top-1/2"
      />

      {/* Collage container */}
      <div className="relative w-[90vw] lg:w-[84vw] h-[85vh] lg:h-[78vh]">
        {/* Card 1 - Top-left photo */}
        <div
          ref={card1Ref}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            left: '0',
            top: '0',
            width: '100%',
            height: '32%',
          }}
        >
          <img
            src="/hero_students_collab.jpg"
            alt="Students collaborating"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Card 2 - Top-right text (accent) */}
        <div
          ref={card2Ref}
          className="absolute card-large bg-lime p-6 lg:p-10 flex flex-col justify-center"
          style={{
            left: '0',
            top: '34%',
            width: '100%',
            height: '32%',
          }}
        >
          <span className="font-mono-label text-[#0B1E2F]/70 mb-3">
            LEAD-WISE OVERSEAS EDUCATION
          </span>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-[#0B1E2F] mb-4">
            <span className="headline-word inline-block">Your</span>{' '}
            <span className="headline-word inline-block">study-abroad</span>{' '}
            <span className="headline-word inline-block">journey,</span>{' '}
            <span className="headline-word inline-block">simplified.</span>
          </h1>
          <p className="text-[#0B1E2F]/80 text-sm lg:text-base mb-4">
            Counseling + test prep, designed around your goals.
          </p>
          <button
            onClick={() => scrollToSection('#contact')}
            className="btn-primary w-fit text-sm"
          >
            Book a free call
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>

        {/* Card 3 - Bottom-left text */}
        <div
          ref={card3Ref}
          className="absolute card-large bg-white border-2 border-[#0B1E2F] p-6 lg:p-8 flex flex-col justify-center"
          style={{
            left: '0',
            top: '68%',
            width: '58%',
            height: '30%',
          }}
        >
          <p className="text-[#0B1E2F] text-sm lg:text-base leading-relaxed mb-4">
            We help you choose the right country, course, and timeline—then
            train you to score high and apply with confidence.
          </p>
          <button
            onClick={() => scrollToSection('#destinations')}
            className="inline-flex items-center text-[#0B1E2F] font-medium text-sm hover:underline w-fit"
          >
            <MapPin className="w-4 h-4 mr-2" />
            Explore destinations
          </button>
        </div>

        {/* Card 4 - Bottom-right photo */}
        <div
          ref={card4Ref}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            right: '0',
            top: '68%',
            width: '40%',
            height: '30%',
          }}
        >
          <img
            src="/hero_student_laptop.jpg"
            alt="Student working on laptop"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Desktop layout - repositioned for larger screens */}
      <style>{`
        @media (min-width: 1024px) {
          .section-pinned > div:nth-child(2) > div:nth-child(2) {
            left: 44% !important;
            top: 0 !important;
            width: 54% !important;
            height: 42% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(3) {
            left: 0 !important;
            top: 46% !important;
            width: 58% !important;
            height: 52% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(4) {
            left: 60% !important;
            top: 46% !important;
            width: 38% !important;
            height: 52% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(1) {
            width: 42% !important;
            height: 42% !important;
          }
        }
      `}</style>
    </section>
  );
};

export default HeroSection;
