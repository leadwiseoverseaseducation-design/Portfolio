import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface TestimonialSectionProps {
  className?: string;
}

const TestimonialSection = ({ className = '' }: TestimonialSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardT1Ref = useRef<HTMLDivElement>(null);
  const cardT2Ref = useRef<HTMLDivElement>(null);
  const cardT3Ref = useRef<HTMLDivElement>(null);
  const cardT4Ref = useRef<HTMLDivElement>(null);
  const blobRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        cardT1Ref.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardT4Ref.current,
        { x: '60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardT2Ref.current,
        { x: '40vw', y: '-30vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        cardT3Ref.current,
        { x: '-40vw', y: '30vh', opacity: 0 },
        { x: 0, y: 0, opacity: 1, ease: 'none' },
        0
      );

      // Quote chip
      const quoteChip = section.querySelector('.quote-chip');
      if (quoteChip) {
        scrollTl.fromTo(
          quoteChip,
          { scale: 0.5, opacity: 0 },
          { scale: 1, opacity: 1, ease: 'none' },
          0.2
        );
      }

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.fromTo(
        cardT1Ref.current,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardT4Ref.current,
        { y: 0, opacity: 1 },
        { y: '18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardT2Ref.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        cardT3Ref.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  // Blob rotation
  useLayoutEffect(() => {
    if (blobRef.current) {
      gsap.to(blobRef.current, {
        rotation: 8,
        duration: 12,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="testimonials"
      className={`section-pinned bg-[#F6F6F2] flex items-center justify-center ${className}`}
    >
      {/* Background blob */}
      <div
        ref={blobRef}
        className="blob w-[55vw] h-[55vh] bg-[#C8FF2E]/20 right-[10%] top-[15%]"
      />

      {/* Collage container */}
      <div className="relative w-[90vw] lg:w-[86vw] h-[85vh] lg:h-[80vh]">
        {/* Card T1 - Top-left (accent) */}
        <div
          ref={cardT1Ref}
          className="absolute card-large bg-lime p-6 lg:p-10 flex flex-col justify-center"
          style={{
            left: '0',
            top: '0',
            width: '100%',
            height: '30%',
          }}
        >
          <h3 className="font-display text-2xl lg:text-3xl font-bold text-[#0B1E2F] mb-3">
            They made it. So can you.
          </h3>
          <p className="text-[#0B1E2F]/80 text-sm lg:text-base">
            From low scores to top admits, our students prove that the right
            plan beats the perfect profile.
          </p>
        </div>

        {/* Card T2 - Top-right (image) */}
        <div
          ref={cardT2Ref}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            left: '0',
            top: '32%',
            width: '100%',
            height: '30%',
          }}
        >
          <img
            src="/testimonial_campus.jpg"
            alt="Students on campus"
            className="w-full h-full object-cover"
          />
          {/* Quote chip */}
          <div className="quote-chip absolute top-4 left-4 w-10 h-10 rounded-full bg-[#C8FF2E] flex items-center justify-center shadow-lg">
            <Quote className="w-5 h-5 text-[#0B1E2F]" />
          </div>
        </div>

        {/* Card T3 - Bottom-left (image) */}
        <div
          ref={cardT3Ref}
          className="absolute card-large overflow-hidden shadow-lg"
          style={{
            left: '0',
            top: '64%',
            width: '48%',
            height: '34%',
          }}
        >
          <img
            src="/testimonial_library.jpg"
            alt="Student studying in library"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Card T4 - Bottom-right (accent with quote) */}
        <div
          ref={cardT4Ref}
          className="absolute card-large bg-lime p-6 lg:p-8 flex flex-col justify-center"
          style={{
            right: '0',
            top: '64%',
            width: '50%',
            height: '34%',
          }}
        >
          <Quote className="w-6 h-6 text-[#0B1E2F] mb-3" />
          <p className="text-[#0B1E2F] text-sm lg:text-base italic mb-4">
            "I was confused between Canada and Ireland. Lead-Wise helped me
            decide, improved my IELTS, and handled my SOP in 10 days."
          </p>
          <p className="text-[#0B1E2F]/70 text-xs lg:text-sm">
            Aishwarya R. — MSc Data Science, Ireland
          </p>
          <button className="inline-flex items-center text-[#0B1E2F] font-medium text-sm hover:underline mt-4 w-fit">
            Read more stories
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>
      </div>

      {/* Desktop layout adjustments */}
      <style>{`
        @media (min-width: 1024px) {
          .section-pinned > div:nth-child(2) > div:nth-child(2) {
            width: 48% !important;
            height: 46% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(3) {
            left: 52% !important;
            top: 0 !important;
            width: 48% !important;
            height: 46% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(4) {
            width: 48% !important;
            height: 50% !important;
            top: 50% !important;
          }
          .section-pinned > div:nth-child(2) > div:nth-child(5) {
            width: 50% !important;
            height: 50% !important;
            top: 50% !important;
          }
        }
      `}</style>
    </section>
  );
};

export default TestimonialSection;
