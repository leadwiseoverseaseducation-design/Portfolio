import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, BookOpen } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface BlogSectionProps {
  className?: string;
}

const BlogSection = ({ className = '' }: BlogSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 1,
          },
        }
      );

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.blog-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: '10vh', opacity: 0, scale: 0.98 },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            stagger: 0.1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 85%',
              end: 'top 50%',
              scrub: 1,
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const articles = [
    {
      title: 'How to choose between IELTS and TOEFL',
      tag: 'Test Prep',
      excerpt:
        'Understand the key differences between these two popular English proficiency tests and make the right choice for your study abroad journey.',
      image: '/services_classroom.jpg',
    },
    {
      title: 'SOP mistakes that cost admits',
      tag: 'Applications',
      excerpt:
        'Learn the most common mistakes students make in their Statement of Purpose and how to avoid them to strengthen your application.',
      image: '/services_mentor.jpg',
    },
    {
      title: 'Budget breakdown: UK vs Canada',
      tag: 'Planning',
      excerpt:
        'A comprehensive comparison of tuition fees, living costs, and post-study work opportunities in two of the most popular destinations.',
      image: '/dest_uk.jpg',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="blog"
      className={`section-flowing bg-[#F6F6F2] ${className}`}
    >
      <div className="px-6 lg:px-[6vw]">
        {/* Header */}
        <div ref={headerRef} className="mb-12 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <span className="font-mono-label text-[#6B7885] mb-4 block">
              BLOG
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-[#0B1E2F]">
              Study-smart guides.
            </h2>
          </div>
          <button className="inline-flex items-center text-[#0B1E2F] font-medium hover:underline w-fit">
            Browse all articles
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>

        {/* Cards grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {articles.map((article, index) => (
            <div
              key={index}
              className="blog-card group card-large overflow-hidden bg-white border border-[#0B1E2F]/10 cursor-pointer hover:border-[#C8FF2E] transition-colors"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-[#C8FF2E] text-[#0B1E2F] text-xs font-medium rounded-full">
                    {article.tag}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="font-display text-lg font-bold text-[#0B1E2F] mb-2 group-hover:text-[#6B7885] transition-colors">
                  {article.title}
                </h3>
                <p className="text-[#6B7885] text-sm leading-relaxed mb-4">
                  {article.excerpt}
                </p>
                <div className="flex items-center text-[#0B1E2F] font-medium text-sm">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Read article
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BlogSection;
