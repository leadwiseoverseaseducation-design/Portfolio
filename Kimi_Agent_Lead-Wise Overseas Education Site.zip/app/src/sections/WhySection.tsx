import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Users, Globe, Award } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface WhySectionProps {
  className?: string;
}

const WhySection = ({ className = '' }: WhySectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const photoRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Photo card animation
      gsap.fromTo(
        photoRef.current,
        { x: '-12vw', opacity: 0, scale: 0.98 },
        {
          x: 0,
          opacity: 1,
          scale: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 45%',
            scrub: 1,
          },
        }
      );

      // Text block animation
      gsap.fromTo(
        textRef.current,
        { x: '10vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            end: 'top 40%',
            scrub: 1,
          },
        }
      );

      // Stats card animation
      gsap.fromTo(
        statsRef.current,
        { y: '10vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            end: 'top 30%',
            scrub: 1,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const features = [
    'Personalized university shortlists',
    'IELTS/TOEFL/GRE coaching that fits your schedule',
    'SOPs, LORs, and visa docs—reviewed, not templated',
  ];

  const stats = [
    { value: '94%', label: 'visa success rate', icon: Award },
    { value: '1,200+', label: 'students coached', icon: Users },
    { value: '12', label: 'countries supported', icon: Globe },
  ];

  return (
    <section
      ref={sectionRef}
      id="why"
      className={`section-flowing bg-[#F6F6F2] ${className}`}
    >
      {/* Diagonal band decoration */}
      <div className="absolute left-0 top-0 w-1/3 h-full opacity-5">
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="w-full h-full"
        >
          <polygon points="0,0 100,0 60,100 0,100" fill="#0B1E2F" />
        </svg>
      </div>

      <div className="relative px-6 lg:px-[6vw]">
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          {/* Left photo card */}
          <div
            ref={photoRef}
            className="w-full lg:w-[40%] card-large overflow-hidden shadow-lg"
            style={{ height: 'clamp(300px, 50vh, 500px)' }}
          >
            <img
              src="/why_counseling.jpg"
              alt="One-on-one counseling session"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Right text block */}
          <div
            ref={textRef}
            className="w-full lg:w-[50%] flex flex-col justify-center py-8"
          >
            <span className="font-mono-label text-[#6B7885] mb-4">
              WHY LEAD-WISE
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-[#0B1E2F] mb-6">
              Coaching + counseling under one roof.
            </h2>
            <p className="text-[#6B7885] text-base lg:text-lg leading-relaxed mb-8">
              Most consultancies stop at admission. We start earlier—by building
              your profile, improving your scores, and shaping your story—so
              applications are stronger and decisions are clearer.
            </p>

            <ul className="space-y-4">
              {features.map((feature, index) => (
                <li
                  key={index}
                  className="flex items-start gap-3"
                >
                  <div className="w-6 h-6 rounded-full bg-[#C8FF2E] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Check className="w-4 h-4 text-[#0B1E2F]" />
                  </div>
                  <span className="text-[#0B1E2F] text-sm lg:text-base">
                    {feature}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Stats accent card */}
        <div
          ref={statsRef}
          className="mt-8 lg:mt-12 w-full lg:w-[40%] card-medium bg-lime p-6 lg:p-8"
        >
          <div className="grid grid-cols-3 gap-4">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="w-6 h-6 text-[#0B1E2F] mx-auto mb-2" />
                <div className="font-display text-2xl lg:text-3xl font-bold text-[#0B1E2F]">
                  {stat.value}
                </div>
                <div className="text-xs lg:text-sm text-[#0B1E2F]/70 mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhySection;
