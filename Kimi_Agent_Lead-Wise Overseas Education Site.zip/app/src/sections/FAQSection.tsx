import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown, MessageCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface FAQSectionProps {
  className?: string;
}

const FAQSection = ({ className = '' }: FAQSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const accordionRef = useRef<HTMLDivElement>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 1,
          },
        }
      );

      // Accordion items animation
      const items = accordionRef.current?.querySelectorAll('.faq-item');
      if (items) {
        gsap.fromTo(
          items,
          { y: 24, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            stagger: 0.06,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: accordionRef.current,
              start: 'top 85%',
              end: 'top 50%',
              scrub: 1,
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const faqs = [
    {
      question: 'Do you help with only admissions or also test prep?',
      answer:
        'We provide both! Lead-Wise offers comprehensive test prep for IELTS, TOEFL, PTE, GRE, and GMAT, along with end-to-end admission counseling. Our integrated approach ensures your test scores align with your university targets.',
    },
    {
      question: 'When should I start preparing?',
      answer:
        'Ideally, start 6-12 months before your intended intake. This gives you ample time for test preparation, university research, application drafting, and visa processing. However, we can also help with shorter timelines when needed.',
    },
    {
      question: 'Can you help with education loans?',
      answer:
        'Yes, we guide you through the entire education loan process. We help you understand loan options, prepare required documentation, and connect you with trusted financial partners who specialize in study abroad loans.',
    },
    {
      question: 'Do you guarantee admits?',
      answer:
        'No ethical consultancy can guarantee admissions. What we guarantee is our commitment to presenting your best possible application. Our 94% visa success rate and 850+ admits speak to the quality of our work.',
    },
    {
      question: 'What if my scores are low?',
      answer:
        'Low scores don\'t mean the end of your study abroad dreams. We help identify universities that value holistic profiles, suggest pathway programs, and work on strengthening other aspects of your application like SOPs and LORs.',
    },
    {
      question: 'How do I book a free call?',
      answer:
        'Simply click the "Book a free call" button anywhere on our website, fill out a short form with your details and goals, and we\'ll schedule a call at your convenience. The call is completely free with no obligations.',
    },
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section
      ref={sectionRef}
      id="faq"
      className={`section-flowing bg-[#F6F6F2] ${className}`}
    >
      <div className="px-6 lg:px-[6vw]">
        {/* Header */}
        <div ref={headerRef} className="mb-12">
          <span className="font-mono-label text-[#6B7885] mb-4 block">
            FAQ
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-[#0B1E2F]">
            Clear answers. No jargon.
          </h2>
        </div>

        {/* Accordion */}
        <div ref={accordionRef} className="max-w-4xl">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="faq-item card-small bg-white border border-[#0B1E2F]/10 overflow-hidden"
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left"
                >
                  <span className="font-display text-base lg:text-lg font-semibold text-[#0B1E2F] pr-4">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#0B1E2F] flex-shrink-0 transition-transform duration-300 ${
                      openIndex === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96' : 'max-h-0'
                  }`}
                >
                  <div className="px-6 pb-5">
                    <p className="text-[#6B7885] text-sm lg:text-base leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA row */}
        <div className="mt-12 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <MessageCircle className="w-6 h-6 text-[#6B7885]" />
          <p className="text-[#0B1E2F] text-base">Still have questions? Message us.</p>
          <button className="btn-accent text-sm">
            Start a chat
          </button>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
