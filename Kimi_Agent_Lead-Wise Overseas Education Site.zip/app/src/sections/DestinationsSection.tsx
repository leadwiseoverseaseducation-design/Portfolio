import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Compass } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface DestinationsSectionProps {
  className?: string;
}

const DestinationsSection = ({ className = '' }: DestinationsSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 1,
          },
        }
      );

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.destination-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: '10vh', opacity: 0, scale: 0.98 },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            stagger: 0.1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 85%',
              end: 'top 50%',
              scrub: 1,
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const destinations = [
    {
      name: 'UK',
      description: 'Post-study work visa · Top-ranked universities',
      image: '/dest_uk.jpg',
    },
    {
      name: 'USA',
      description: 'Flexible programs · Research opportunities',
      image: '/dest_usa.jpg',
    },
    {
      name: 'Canada',
      description: 'PGWP friendly · PR pathways',
      image: '/dest_canada.jpg',
    },
    {
      name: 'Australia',
      description: 'High quality of life · Strong graduate outcomes',
      image: '/dest_australia.jpg',
    },
    {
      name: 'Germany',
      description: 'Low/no tuition · Industry-linked degrees',
      image: '/dest_germany.jpg',
    },
    {
      name: 'Ireland',
      description: '2-year stay-back · Tech & pharma hubs',
      image: '/dest_ireland.jpg',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="destinations"
      className={`section-flowing bg-[#F6F6F2] ${className}`}
    >
      <div className="px-6 lg:px-[6vw]">
        {/* Header */}
        <div ref={headerRef} className="mb-12">
          <span className="font-mono-label text-[#6B7885] mb-4 block">
            DESTINATIONS
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-[#0B1E2F] mb-4">
            Study where you belong.
          </h2>
          <p className="text-[#6B7885] text-base lg:text-lg max-w-2xl">
            Popular countries, clear requirements, and timelines that match your
            intake.
          </p>
        </div>

        {/* Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {destinations.map((dest, index) => (
            <div
              key={index}
              className="destination-card group relative card-large overflow-hidden cursor-pointer"
              style={{ height: 'clamp(280px, 35vh, 380px)' }}
            >
              {/* Background image */}
              <img
                src={dest.image}
                alt={dest.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />

              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B1E2F]/90 via-[#0B1E2F]/30 to-transparent" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="font-display text-2xl lg:text-3xl font-bold text-white mb-2">
                  {dest.name}
                </h3>
                <p className="text-white/80 text-sm">{dest.description}</p>
              </div>

              {/* Hover effect */}
              <div className="absolute inset-0 border-4 border-[#C8FF2E] opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-[32px]" />
            </div>
          ))}
        </div>

        {/* CTA row */}
        <div className="mt-12 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <Compass className="w-6 h-6 text-[#6B7885]" />
          <p className="text-[#0B1E2F] text-base">
            Not sure where to apply? Take the 2-minute match quiz.
          </p>
          <button className="btn-accent text-sm">
            Match me to a country
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default DestinationsSection;
